<template>
	<view style="height: 15rpx;background-color: #F5F5F4;"></view>
</template>

<script>
</script>

<style>
</style>
